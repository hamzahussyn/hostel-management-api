exports.USER_ROLES = {
  ADMIN: 'Admin',
  GUEST: 'Guest'
}