exports.TENANT_STATUS = {
  RENT_DUE: 'rentdue',
  SLIP_DUE: 'slipdue',
  PAID: 'paid'
};

exports.SEARCH_COLUMNS = {
  NAME: 'name',
  CNIC: 'cnic',
};
