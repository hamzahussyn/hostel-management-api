exports.SLIP_TYPES = {
  RENT: 'Rent',
  DEPOSIT: 'Deposit',
  ARREARS: 'Arrears',
  OTHERS: 'Others'
}

exports.SLIP_STATUS = {
  PAID: 'paid',
  UNPAID: 'unpaid'
}